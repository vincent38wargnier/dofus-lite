# Kit de création complet

Ouvrez **retro-class-designer/assets/ai-design/index.html** pour les prompts visuels, les gabarits et les guides des cartes. Cette page fonctionne hors ligne.

- Visuels : `retro-class-designer/assets/ai-design/START-HERE.md`
- Animations de sorts : `retro-class-designer/assets/ai-design/spell-fx/index.html` (aperçu hors ligne), `references/spell-fx-design.md` et prompts 17–23 dans `assets/ai-design/prompts/`
- Classes, donjons, JSON et règles : `retro-class-designer/references/runtime-zip.md`
- Aventures équipées et export : `retro-class-designer/references/content-packages.md`
- Prompts complets : `retro-class-designer/assets/runtime-class-prompt.txt` et `runtime-dungeon-prompt.txt`

## Valider avec les calculs du jeu

Node.js 20+ suffit, sans npm, réseau ni dépôt du jeu. Depuis ce dossier :

```bash
node retro-class-designer/scripts/validate.cjs package mon-package.zip
node retro-class-designer/scripts/validate.cjs equipment mon-objet.json
node retro-class-designer/scripts/validate.cjs character mon-personnage.json
node retro-class-designer/scripts/check-spell-fx.cjs design-sources/spell-fx/mon-sort
```

Le rapport JSON contrôle les sorts (100 / 650), objets (100), stuffs (1650 hors Dofus), niveaux, FM et conditions. Le mode package contrôle aussi les dépendances et PNG. Voir `retro-class-designer/references/validation.md` pour les formats, exemples et limites. Un brouillon importable peut être refusé pour le combat.

Ce kit est de la documentation, pas un ZIP de jeu à importer. Les personnages et icônes de sorts sont importables ; les décors de carte, PNG d'équipement et nouvelles animations de sorts restent des sources de design. Le vérificateur d'effets contrôle leurs PNG et leur timing ; il ne les installe pas en combat.
